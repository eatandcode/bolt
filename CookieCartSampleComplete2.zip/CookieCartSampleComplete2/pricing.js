var items=["lgtv","sonytv"];
var prices=[600,850];

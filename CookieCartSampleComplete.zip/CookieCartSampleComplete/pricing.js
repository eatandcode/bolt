var items=["radio","dvd","item3"];
var prices=[100,50,15];
